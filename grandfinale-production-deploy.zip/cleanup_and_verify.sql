-- Cleanup script to remove duplicates and verify dummy accounts
-- First, let's see what we have
SELECT 'Current state before cleanup:' as status;

-- Show all users with their personal info
SELECT 
    u.id,
    u.email,
    pi.legal_first_name,
    pi.legal_last_name,
    pi.created_at
FROM users u
LEFT JOIN personal_info pi ON u.id = pi.user_id
ORDER BY pi.legal_last_name, pi.legal_first_name;

-- Remove duplicates from personal_info (keep the first one for each user_id)
DELETE FROM personal_info 
WHERE id NOT IN (
    SELECT DISTINCT ON (user_id) id 
    FROM personal_info 
    ORDER BY user_id, created_at
);

-- Remove duplicates from addresses (keep the first one for each user_id)
DELETE FROM addresses 
WHERE id NOT IN (
    SELECT DISTINCT ON (user_id) id 
    FROM addresses 
    ORDER BY user_id, created_at
);

-- Remove duplicates from phones (keep the first one for each user_id)
DELETE FROM phones 
WHERE id NOT IN (
    SELECT DISTINCT ON (user_id) id 
    FROM phones 
    ORDER BY user_id, created_at
);

-- Remove duplicates from emergency_contacts (keep the first one for each user_id)
DELETE FROM emergency_contacts 
WHERE id NOT IN (
    SELECT DISTINCT ON (user_id) id 
    FROM emergency_contacts 
    ORDER BY user_id, created_at
);

-- Now let's verify the clean state
SELECT 'Clean state after removing duplicates:' as status;

-- Show all users with their personal info
SELECT 
    u.id,
    u.email,
    pi.legal_first_name,
    pi.legal_last_name,
    pi.created_at
FROM users u
LEFT JOIN personal_info pi ON u.id = pi.user_id
ORDER BY pi.legal_last_name, pi.legal_first_name;

-- Count records in each table
SELECT 'personal_info count:' as table_name, COUNT(*) as count FROM personal_info
UNION ALL
SELECT 'addresses count:', COUNT(*) FROM addresses
UNION ALL
SELECT 'phones count:', COUNT(*) FROM phones
UNION ALL
SELECT 'emergency_contacts count:', COUNT(*) FROM emergency_contacts;

-- Show a summary of all dummy accounts
SELECT 
    'Dummy Account Summary:' as summary,
    u.email,
    pi.legal_first_name,
    pi.legal_last_name,
    CASE 
        WHEN u.email LIKE '%.lite.%' THEN 'Lite'
        WHEN u.email LIKE '%.standard.%' THEN 'Standard'
        WHEN u.email LIKE '%.premium.%' THEN 'Premium'
        WHEN u.email LIKE '%.lifetime.%' THEN 'Lifetime'
        ELSE 'Unknown'
    END as tier,
    CASE 
        WHEN u.email LIKE '%.monthly@%' THEN 'Monthly'
        WHEN u.email LIKE '%.yearly@%' THEN 'Yearly'
        WHEN u.email LIKE '%.lifetime@%' THEN 'Lifetime'
        ELSE 'Unknown'
    END as billing
FROM users u
LEFT JOIN personal_info pi ON u.id = pi.user_id
WHERE u.email LIKE '%@epoxydogs.com'
ORDER BY pi.legal_last_name, pi.legal_first_name; 