-- Dummy Accounts with Unique Emails for Supabase Auth
-- This version uses unique email addresses for each pricing tier

-- Insert dummy users for all pricing tiers with unique emails
INSERT INTO users (email, created_at, updated_at) VALUES
-- Monthly Plans
('dummy.lite.monthly@epoxydogs.com', now(), now()),
('dummy.standard.monthly@epoxydogs.com', now(), now()),
('dummy.premium.monthly@epoxydogs.com', now(), now()),
('dummy.lifetime@epoxydogs.com', now(), now()),

-- Yearly Plans  
('dummy.lite.yearly@epoxydogs.com', now(), now()),
('dummy.standard.yearly@epoxydogs.com', now(), now()),
('dummy.premium.yearly@epoxydogs.com', now(), now()),
('dummy.lifetime.yearly@epoxydogs.com', now(), now());

-- Insert personal information for each dummy account
INSERT INTO personal_info (user_id, legal_first_name, legal_last_name, preferred_name, date_of_birth, place_of_birth, country_of_citizenship, language_spoken, created_at, updated_at) VALUES
-- Monthly Plans
((SELECT id FROM users WHERE email = 'dummy.lite.monthly@epoxydogs.com'), 'Dummy', 'Lite-Monthly', 'Dummy Lite', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
((SELECT id FROM users WHERE email = 'dummy.standard.monthly@epoxydogs.com'), 'Dummy', 'Standard-Monthly', 'Dummy Standard', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
((SELECT id FROM users WHERE email = 'dummy.premium.monthly@epoxydogs.com'), 'Dummy', 'Premium-Monthly', 'Dummy Premium', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
((SELECT id FROM users WHERE email = 'dummy.lifetime@epoxydogs.com'), 'Dummy', 'Lifetime', 'Dummy Lifetime', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),

-- Yearly Plans
((SELECT id FROM users WHERE email = 'dummy.lite.yearly@epoxydogs.com'), 'Dummy', 'Lite-Yearly', 'Dummy Lite Yearly', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
((SELECT id FROM users WHERE email = 'dummy.standard.yearly@epoxydogs.com'), 'Dummy', 'Standard-Yearly', 'Dummy Standard Yearly', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
((SELECT id FROM users WHERE email = 'dummy.premium.yearly@epoxydogs.com'), 'Dummy', 'Premium-Yearly', 'Dummy Premium Yearly', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
((SELECT id FROM users WHERE email = 'dummy.lifetime.yearly@epoxydogs.com'), 'Dummy', 'Lifetime-Yearly', 'Dummy Lifetime Yearly', '1990-01-01', 'Test City', 'United States', 'English', now(), now());

-- Insert sample addresses for each dummy account
INSERT INTO addresses (user_id, address_type, street, city, state, zip, country, is_primary, created_at, updated_at) VALUES
-- Monthly Plans
((SELECT id FROM users WHERE email = 'dummy.lite.monthly@epoxydogs.com'), 'Current', '123 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
((SELECT id FROM users WHERE email = 'dummy.standard.monthly@epoxydogs.com'), 'Current', '456 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
((SELECT id FROM users WHERE email = 'dummy.premium.monthly@epoxydogs.com'), 'Current', '789 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
((SELECT id FROM users WHERE email = 'dummy.lifetime@epoxydogs.com'), 'Current', '101 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),

-- Yearly Plans
((SELECT id FROM users WHERE email = 'dummy.lite.yearly@epoxydogs.com'), 'Current', '202 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
((SELECT id FROM users WHERE email = 'dummy.standard.yearly@epoxydogs.com'), 'Current', '303 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
((SELECT id FROM users WHERE email = 'dummy.premium.yearly@epoxydogs.com'), 'Current', '404 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
((SELECT id FROM users WHERE email = 'dummy.lifetime.yearly@epoxydogs.com'), 'Current', '505 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now());

-- Insert sample phone numbers for each dummy account
INSERT INTO phones (user_id, phone_type, phone_number, is_primary, created_at, updated_at) VALUES
-- Monthly Plans
((SELECT id FROM users WHERE email = 'dummy.lite.monthly@epoxydogs.com'), 'Mobile', '555-0101', true, now(), now()),
((SELECT id FROM users WHERE email = 'dummy.standard.monthly@epoxydogs.com'), 'Mobile', '555-0102', true, now(), now()),
((SELECT id FROM users WHERE email = 'dummy.premium.monthly@epoxydogs.com'), 'Mobile', '555-0103', true, now(), now()),
((SELECT id FROM users WHERE email = 'dummy.lifetime@epoxydogs.com'), 'Mobile', '555-0104', true, now(), now()),

-- Yearly Plans
((SELECT id FROM users WHERE email = 'dummy.lite.yearly@epoxydogs.com'), 'Mobile', '555-0105', true, now(), now()),
((SELECT id FROM users WHERE email = 'dummy.standard.yearly@epoxydogs.com'), 'Mobile', '555-0106', true, now(), now()),
((SELECT id FROM users WHERE email = 'dummy.premium.yearly@epoxydogs.com'), 'Mobile', '555-0107', true, now(), now()),
((SELECT id FROM users WHERE email = 'dummy.lifetime.yearly@epoxydogs.com'), 'Mobile', '555-0108', true, now(), now());

-- Insert sample emergency contacts for each dummy account
INSERT INTO emergency_contacts (user_id, full_name, relationship, phone, email, address, city, state, zip, country, is_primary, notes, created_at, updated_at) VALUES
-- Monthly Plans
((SELECT id FROM users WHERE email = 'dummy.lite.monthly@epoxydogs.com'), 'Test Contact Lite', 'Friend', '555-0201', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Lite Monthly plan', now(), now()),
((SELECT id FROM users WHERE email = 'dummy.standard.monthly@epoxydogs.com'), 'Test Contact Standard', 'Friend', '555-0202', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Standard Monthly plan', now(), now()),
((SELECT id FROM users WHERE email = 'dummy.premium.monthly@epoxydogs.com'), 'Test Contact Premium', 'Friend', '555-0203', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Premium Monthly plan', now(), now()),
((SELECT id FROM users WHERE email = 'dummy.lifetime@epoxydogs.com'), 'Test Contact Lifetime', 'Friend', '555-0204', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Lifetime plan', now(), now()),

-- Yearly Plans
((SELECT id FROM users WHERE email = 'dummy.lite.yearly@epoxydogs.com'), 'Test Contact Lite Yearly', 'Friend', '555-0205', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Lite Yearly plan', now(), now()),
((SELECT id FROM users WHERE email = 'dummy.standard.yearly@epoxydogs.com'), 'Test Contact Standard Yearly', 'Friend', '555-0206', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Standard Yearly plan', now(), now()),
((SELECT id FROM users WHERE email = 'dummy.premium.yearly@epoxydogs.com'), 'Test Contact Premium Yearly', 'Friend', '555-0207', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Premium Yearly plan', now(), now()),
((SELECT id FROM users WHERE email = 'dummy.lifetime.yearly@epoxydogs.com'), 'Test Contact Lifetime Yearly', 'Friend', '555-0208', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Lifetime Yearly plan', now(), now());

-- Display the created dummy accounts
SELECT 
    u.id as user_id,
    u.email,
    pi.legal_first_name,
    pi.legal_last_name,
    pi.preferred_name,
    a.street,
    a.city,
    a.state,
    p.phone_number,
    ec.full_name as emergency_contact
FROM users u
LEFT JOIN personal_info pi ON u.id = pi.user_id
LEFT JOIN addresses a ON u.id = a.user_id AND a.is_primary = true
LEFT JOIN phones p ON u.id = p.user_id AND p.is_primary = true
LEFT JOIN emergency_contacts ec ON u.id = ec.user_id AND ec.is_primary = true
WHERE u.email LIKE 'dummy.%@epoxydogs.com'
ORDER BY pi.legal_last_name; 