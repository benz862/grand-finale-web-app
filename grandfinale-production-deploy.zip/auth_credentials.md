# Dummy Account Login Credentials

## How to Create Auth Users

### Step 1: Create Database Records
Run the `dummy_accounts_unique_emails.sql` script in your Supabase SQL editor to create the database records.

### Step 2: Create Auth Users
Go to your Supabase Dashboard → Authentication → Users → Add User for each account below:

## Monthly Plans

### Dummy Lite-Monthly
- **Email:** dummy.lite.monthly@epoxydogs.com
- **Password:** DummyLite2024!
- **Plan:** Lite ($4/mo)

### Dummy Standard-Monthly  
- **Email:** dummy.standard.monthly@epoxydogs.com
- **Password:** DummyStandard2024!
- **Plan:** Standard ($8/mo)

### Dummy Premium-Monthly
- **Email:** dummy.premium.monthly@epoxydogs.com
- **Password:** DummyPremium2024!
- **Plan:** Premium ($12/mo)

### Dummy Lifetime
- **Email:** dummy.lifetime@epoxydogs.com
- **Password:** DummyLifetime2024!
- **Plan:** Lifetime ($199 one-time)

## Yearly Plans

### Dummy Lite-Yearly
- **Email:** dummy.lite.yearly@epoxydogs.com
- **Password:** DummyLiteYearly2024!
- **Plan:** Lite ($40/yr)

### Dummy Standard-Yearly
- **Email:** dummy.standard.yearly@epoxydogs.com
- **Password:** DummyStandardYearly2024!
- **Plan:** Standard ($80/yr)

### Dummy Premium-Yearly
- **Email:** dummy.premium.yearly@epoxydogs.com
- **Password:** DummyPremiumYearly2024!
- **Plan:** Premium ($120/yr)

### Dummy Lifetime-Yearly
- **Email:** dummy.lifetime.yearly@epoxydogs.com
- **Password:** DummyLifetimeYearly2024!
- **Plan:** Lifetime ($199 one-time)

## Quick Setup Commands

### Via Supabase CLI (if you have it installed):
```bash
supabase auth create-user --email dummy.lite.monthly@epoxydogs.com --password DummyLite2024!
supabase auth create-user --email dummy.standard.monthly@epoxydogs.com --password DummyStandard2024!
supabase auth create-user --email dummy.premium.monthly@epoxydogs.com --password DummyPremium2024!
supabase auth create-user --email dummy.lifetime@epoxydogs.com --password DummyLifetime2024!
supabase auth create-user --email dummy.lite.yearly@epoxydogs.com --password DummyLiteYearly2024!
supabase auth create-user --email dummy.standard.yearly@epoxydogs.com --password DummyStandardYearly2024!
supabase auth create-user --email dummy.premium.yearly@epoxydogs.com --password DummyPremiumYearly2024!
supabase auth create-user --email dummy.lifetime.yearly@epoxydogs.com --password DummyLifetimeYearly2024!
```

### Via JavaScript/TypeScript (in your app):
```javascript
import { createClient } from '@supabase/supabase-js'

const supabase = createClient('YOUR_SUPABASE_URL', 'YOUR_SUPABASE_ANON_KEY')

// Create all auth users
const users = [
  { email: 'dummy.lite.monthly@epoxydogs.com', password: 'DummyLite2024!' },
  { email: 'dummy.standard.monthly@epoxydogs.com', password: 'DummyStandard2024!' },
  { email: 'dummy.premium.monthly@epoxydogs.com', password: 'DummyPremium2024!' },
  { email: 'dummy.lifetime@epoxydogs.com', password: 'DummyLifetime2024!' },
  { email: 'dummy.lite.yearly@epoxydogs.com', password: 'DummyLiteYearly2024!' },
  { email: 'dummy.standard.yearly@epoxydogs.com', password: 'DummyStandardYearly2024!' },
  { email: 'dummy.premium.yearly@epoxydogs.com', password: 'DummyPremiumYearly2024!' },
  { email: 'dummy.lifetime.yearly@epoxydogs.com', password: 'DummyLifetimeYearly2024!' }
]

for (const user of users) {
  const { data, error } = await supabase.auth.admin.createUser({
    email: user.email,
    password: user.password,
    email_confirm: true
  })
  console.log(`Created user: ${user.email}`, error || 'Success')
}
```

## Notes
- All passwords follow the pattern: `Dummy[Plan][Period]2024!`
- Each account has unique email addresses to work with Supabase Auth
- All accounts use the same personal information structure but with different names
- You can use these accounts to test different pricing tier features in your app 