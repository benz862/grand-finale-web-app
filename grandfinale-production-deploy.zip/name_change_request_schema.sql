-- Name Change Request System Schema
-- Add this to your Supabase database to support the name change request functionality

-- 1. Create name_change_requests table
CREATE TABLE name_change_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    request_id VARCHAR(50) UNIQUE NOT NULL, -- e.g., "NCR-1721174400000"
    
    -- Current name (at time of request)
    current_first_name VARCHAR(100) NOT NULL,
    current_middle_name VARCHAR(100),
    current_last_name VARCHAR(100) NOT NULL,
    
    -- Requested new name
    requested_first_name VARCHAR(100) NOT NULL,
    requested_middle_name VARCHAR(100),
    requested_last_name VARCHAR(100) NOT NULL,
    
    -- Request details
    reason VARCHAR(50) NOT NULL CHECK (reason IN ('marriage', 'divorce', 'legal_change', 'correction', 'other')),
    details TEXT,
    
    -- Status tracking
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'denied', 'processing')),
    admin_notes TEXT,
    reviewed_by UUID REFERENCES users(id), -- admin who reviewed
    reviewed_at TIMESTAMP,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT now(),
    updated_at TIMESTAMP DEFAULT now()
);

-- 2. Add columns to personal_info table to track immutable data status
ALTER TABLE personal_info 
ADD COLUMN IF NOT EXISTS has_immutable_data BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS immutable_data_locked_at TIMESTAMP,
ADD COLUMN IF NOT EXISTS legal_middle_name VARCHAR(100); -- if not already present

-- 3. Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_name_change_requests_user_id ON name_change_requests(user_id);
CREATE INDEX IF NOT EXISTS idx_name_change_requests_status ON name_change_requests(status);
CREATE INDEX IF NOT EXISTS idx_name_change_requests_request_id ON name_change_requests(request_id);
CREATE INDEX IF NOT EXISTS idx_personal_info_immutable_data ON personal_info(has_immutable_data);

-- 4. Enable RLS on name_change_requests table
ALTER TABLE name_change_requests ENABLE ROW LEVEL SECURITY;

-- 5. Create RLS policies for name_change_requests
CREATE POLICY "Users can view own name change requests" ON name_change_requests 
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own name change requests" ON name_change_requests 
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own pending requests" ON name_change_requests 
    FOR UPDATE USING (auth.uid() = user_id AND status = 'pending');

-- Admin policies (you'll need to create an admin role)
CREATE POLICY "Admins can view all name change requests" ON name_change_requests 
    FOR SELECT USING (auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Admins can update all name change requests" ON name_change_requests 
    FOR UPDATE USING (auth.jwt() ->> 'role' = 'admin');

-- 6. Create function to automatically update timestamps
CREATE OR REPLACE FUNCTION update_name_change_requests_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- 7. Create trigger for automatic timestamp updates
CREATE TRIGGER update_name_change_requests_updated_at
    BEFORE UPDATE ON name_change_requests
    FOR EACH ROW
    EXECUTE FUNCTION update_name_change_requests_updated_at();

-- 8. Create function to approve name changes (updates personal_info)
CREATE OR REPLACE FUNCTION approve_name_change_request(request_uuid UUID, admin_user_id UUID, notes TEXT DEFAULT NULL)
RETURNS BOOLEAN AS $$
DECLARE
    request_record name_change_requests%ROWTYPE;
BEGIN
    -- Get the request
    SELECT * INTO request_record FROM name_change_requests WHERE id = request_uuid AND status = 'pending';
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Request not found or not pending';
    END IF;
    
    -- Update personal_info with new names
    UPDATE personal_info 
    SET 
        legal_first_name = request_record.requested_first_name,
        legal_middle_name = request_record.requested_middle_name,
        legal_last_name = request_record.requested_last_name,
        updated_at = now()
    WHERE user_id = request_record.user_id;
    
    -- Update request status
    UPDATE name_change_requests 
    SET 
        status = 'approved',
        reviewed_by = admin_user_id,
        reviewed_at = now(),
        admin_notes = notes,
        updated_at = now()
    WHERE id = request_uuid;
    
    RETURN TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 9. Create function to deny name change requests
CREATE OR REPLACE FUNCTION deny_name_change_request(request_uuid UUID, admin_user_id UUID, notes TEXT DEFAULT NULL)
RETURNS BOOLEAN AS $$
BEGIN
    UPDATE name_change_requests 
    SET 
        status = 'denied',
        reviewed_by = admin_user_id,
        reviewed_at = now(),
        admin_notes = notes,
        updated_at = now()
    WHERE id = request_uuid AND status = 'pending';
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Request not found or not pending';
    END IF;
    
    RETURN TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 10. Create view for admin dashboard
CREATE OR REPLACE VIEW admin_name_change_requests AS
SELECT 
    ncr.*,
    u.email as user_email,
    pi.legal_first_name as current_db_first_name,
    pi.legal_last_name as current_db_last_name,
    admin_u.email as reviewed_by_email
FROM name_change_requests ncr
JOIN users u ON ncr.user_id = u.id
LEFT JOIN personal_info pi ON ncr.user_id = pi.user_id
LEFT JOIN users admin_u ON ncr.reviewed_by = admin_u.id
ORDER BY ncr.created_at DESC;

-- Note: Views inherit security from their underlying tables
-- Admin access is controlled by the policies on name_change_requests table

COMMENT ON TABLE name_change_requests IS 'Stores user requests to change their legal names with approval workflow';
COMMENT ON COLUMN name_change_requests.request_id IS 'Human-readable request ID for user reference';
COMMENT ON COLUMN name_change_requests.reason IS 'Reason for name change: marriage, divorce, legal_change, correction, other';
COMMENT ON COLUMN name_change_requests.status IS 'Request status: pending, approved, denied, processing';
