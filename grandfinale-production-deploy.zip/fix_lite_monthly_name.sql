-- Fix the inconsistent last name for dummy.lite.monthly@epoxydogs.com
UPDATE personal_info 
SET legal_last_name = 'Dummy Lite-Monthly'
WHERE user_id = (
    SELECT id FROM users 
    WHERE email = 'dummy.lite.monthly@epoxydogs.com'
);

-- Verify the fix
SELECT 
    u.email,
    pi.legal_first_name,
    pi.legal_last_name
FROM users u
LEFT JOIN personal_info pi ON u.id = pi.user_id
WHERE u.email = 'dummy.lite.monthly@epoxydogs.com'; 