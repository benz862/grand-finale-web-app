-- Setup Storage Buckets and Policies for File Uploads (Clean Version)
-- Run this in your Supabase SQL Editor

-- 1. Create storage buckets (using ON CONFLICT to handle existing buckets)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES 
    (
        'name-change-documents',
        'name-change-documents',
        false, -- private bucket
        10485760, -- 10MB limit
        ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf', 'text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'video/mp4', 'video/webm', 'video/quicktime']
    ),
    (
        'feedback-attachments',
        'feedback-attachments', 
        false, -- private bucket
        10485760, -- 10MB limit
        ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf', 'text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'video/mp4', 'video/webm', 'video/quicktime']
    )
ON CONFLICT (id) DO NOTHING;

-- 2. Drop existing storage policies for name-change-documents bucket (if they exist)
DO $$
BEGIN
    DROP POLICY IF EXISTS "Users can upload name change documents" ON storage.objects;
    DROP POLICY IF EXISTS "Users can view their own name change documents" ON storage.objects;
    DROP POLICY IF EXISTS "Users can delete their own name change documents" ON storage.objects;
EXCEPTION
    WHEN undefined_object THEN
        -- Policy doesn't exist, continue
        NULL;
END $$;

-- 3. Drop existing storage policies for feedback-attachments bucket (if they exist)
DO $$
BEGIN
    DROP POLICY IF EXISTS "Users can upload feedback attachments" ON storage.objects;
    DROP POLICY IF EXISTS "Users can view their own feedback attachments" ON storage.objects;
    DROP POLICY IF EXISTS "Users can delete their own feedback attachments" ON storage.objects;
EXCEPTION
    WHEN undefined_object THEN
        -- Policy doesn't exist, continue
        NULL;
END $$;

-- 4. Create storage policies for name-change-documents bucket
CREATE POLICY "Users can upload name change documents" ON storage.objects
FOR INSERT WITH CHECK (
    bucket_id = 'name-change-documents' 
    AND auth.uid()::text = (storage.foldername(name))[1]
    AND auth.role() = 'authenticated'
);

CREATE POLICY "Users can view their own name change documents" ON storage.objects
FOR SELECT USING (
    bucket_id = 'name-change-documents' 
    AND auth.uid()::text = (storage.foldername(name))[1]
    AND auth.role() = 'authenticated'
);

CREATE POLICY "Users can delete their own name change documents" ON storage.objects
FOR DELETE USING (
    bucket_id = 'name-change-documents' 
    AND auth.uid()::text = (storage.foldername(name))[1]
    AND auth.role() = 'authenticated'
);

-- 5. Create storage policies for feedback-attachments bucket
CREATE POLICY "Users can upload feedback attachments" ON storage.objects
FOR INSERT WITH CHECK (
    bucket_id = 'feedback-attachments' 
    AND auth.uid()::text = (storage.foldername(name))[1]
    AND auth.role() = 'authenticated'
);

CREATE POLICY "Users can view their own feedback attachments" ON storage.objects
FOR SELECT USING (
    bucket_id = 'feedback-attachments' 
    AND auth.uid()::text = (storage.foldername(name))[1]
    AND auth.role() = 'authenticated'
);

CREATE POLICY "Users can delete their own feedback attachments" ON storage.objects
FOR DELETE USING (
    bucket_id = 'feedback-attachments' 
    AND auth.uid()::text = (storage.foldername(name))[1]
    AND auth.role() = 'authenticated'
);

-- 6. Verify the setup
SELECT 
    'Storage Buckets Created:' as info,
    b.id as bucket_id,
    b.name as bucket_name,
    b.public,
    b.file_size_limit / 1024 / 1024 as max_size_mb,
    array_length(b.allowed_mime_types, 1) as mime_types_count
FROM storage.buckets b
WHERE b.id IN ('name-change-documents', 'feedback-attachments')
ORDER BY b.id;

-- 7. Show created policies
SELECT 
    'Storage Policies Created:' as info,
    policyname as policy_name,
    cmd as operation,
    'storage.objects' as table_name
FROM pg_policies 
WHERE tablename = 'objects' 
AND schemaname = 'storage'
AND policyname LIKE '%name change%' OR policyname LIKE '%feedback%'
ORDER BY policyname;
