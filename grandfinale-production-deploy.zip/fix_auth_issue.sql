-- FIX: Authentication Issue with RLS Policies
-- This script fixes the "Failed to create user" error

-- Step 1: Temporarily disable RLS on the users table
ALTER TABLE users DISABLE ROW LEVEL SECURITY;

-- Step 2: Create a trigger to automatically insert into users table when auth.users gets a new user
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.users (id, email, created_at, updated_at)
  VALUES (NEW.id, NEW.email, NEW.created_at, NEW.updated_at);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Step 3: Create the trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Step 4: Re-enable RLS on the users table
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Step 5: Update the RLS policy to allow auth system to insert users
DROP POLICY IF EXISTS "Users can insert own data" ON users;
CREATE POLICY "Users can insert own data" ON users 
FOR INSERT WITH CHECK (auth.uid() = id OR auth.role() = 'service_role');

-- Now try creating auth users again via the Supabase Dashboard
-- The trigger will automatically create the corresponding records in your users table

-- Test: Try creating one auth user first
-- Email: dummy.lite.monthly@epoxydogs.com
-- Password: DummyLite2024!

-- After creating the auth user, check if it worked:
SELECT * FROM users WHERE email = 'dummy.lite.monthly@epoxydogs.com';
SELECT * FROM auth.users WHERE email = 'dummy.lite.monthly@epoxydogs.com'; 