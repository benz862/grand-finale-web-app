-- Disable Row Level Security for development
-- Run this in Supabase SQL Editor to allow the app to work with custom authentication
-- WARNING: This disables security - only use for development!

-- Disable RLS on all tables
ALTER TABLE users DISABLE ROW LEVEL SECURITY;
ALTER TABLE personal_info DISABLE ROW LEVEL SECURITY;
ALTER TABLE addresses DISABLE ROW LEVEL SECURITY;
ALTER TABLE phones DISABLE ROW LEVEL SECURITY;
ALTER TABLE emails DISABLE ROW LEVEL SECURITY;
ALTER TABLE emergency_contacts DISABLE ROW LEVEL SECURITY;
ALTER TABLE legal_documents DISABLE ROW LEVEL SECURITY;
ALTER TABLE children DISABLE ROW LEVEL SECURITY;
ALTER TABLE name_change_requests DISABLE ROW LEVEL SECURITY;

-- Drop existing policies (optional - they won't be enforced anyway with RLS disabled)
DROP POLICY IF EXISTS "Users can view own data" ON users;
DROP POLICY IF EXISTS "Users can update own data" ON users;
DROP POLICY IF EXISTS "Users can insert own data" ON users;

DROP POLICY IF EXISTS "Users can view own personal_info" ON personal_info;
DROP POLICY IF EXISTS "Users can update own personal_info" ON personal_info;
DROP POLICY IF EXISTS "Users can insert own personal_info" ON personal_info;

DROP POLICY IF EXISTS "Users can view own addresses" ON addresses;
DROP POLICY IF EXISTS "Users can update own addresses" ON addresses;
DROP POLICY IF EXISTS "Users can insert own addresses" ON addresses;
DROP POLICY IF EXISTS "Users can delete own addresses" ON addresses;

DROP POLICY IF EXISTS "Users can view own phones" ON phones;
DROP POLICY IF EXISTS "Users can update own phones" ON phones;
DROP POLICY IF EXISTS "Users can insert own phones" ON phones;
DROP POLICY IF EXISTS "Users can delete own phones" ON phones;

DROP POLICY IF EXISTS "Users can view own emails" ON emails;
DROP POLICY IF EXISTS "Users can update own emails" ON emails;
DROP POLICY IF EXISTS "Users can insert own emails" ON emails;
DROP POLICY IF EXISTS "Users can delete own emails" ON emails;

DROP POLICY IF EXISTS "Users can view own emergency_contacts" ON emergency_contacts;
DROP POLICY IF EXISTS "Users can update own emergency_contacts" ON emergency_contacts;
DROP POLICY IF EXISTS "Users can insert own emergency_contacts" ON emergency_contacts;
DROP POLICY IF EXISTS "Users can delete own emergency_contacts" ON emergency_contacts;

DROP POLICY IF EXISTS "Users can view own legal_documents" ON legal_documents;
DROP POLICY IF EXISTS "Users can update own legal_documents" ON legal_documents;
DROP POLICY IF EXISTS "Users can insert own legal_documents" ON legal_documents;
DROP POLICY IF EXISTS "Users can delete own legal_documents" ON legal_documents;

DROP POLICY IF EXISTS "Users can view own children" ON children;
DROP POLICY IF EXISTS "Users can insert own children" ON children;
DROP POLICY IF EXISTS "Users can update own children" ON children;
DROP POLICY IF EXISTS "Users can delete own children" ON children;

DROP POLICY IF EXISTS "Users can view own name change requests" ON name_change_requests;
DROP POLICY IF EXISTS "Users can insert own name change requests" ON name_change_requests;
DROP POLICY IF EXISTS "Users can update own pending requests" ON name_change_requests;
DROP POLICY IF EXISTS "Admins can view all name change requests" ON name_change_requests;
DROP POLICY IF EXISTS "Admins can update all name change requests" ON name_change_requests;
