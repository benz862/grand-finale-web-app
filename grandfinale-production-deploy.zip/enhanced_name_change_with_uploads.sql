-- Enhanced Name Change Request System with File Uploads
-- Add this to your Supabase database to support file uploads for name change requests

-- 1. Create file_uploads table for supporting documents
CREATE TABLE IF NOT EXISTS file_uploads (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    file_name VARCHAR(255) NOT NULL,
    file_size BIGINT NOT NULL,
    file_type VARCHAR(100) NOT NULL,
    file_url TEXT NOT NULL, -- Supabase Storage URL
    storage_path TEXT NOT NULL, -- Path in Supabase Storage
    upload_purpose VARCHAR(50) NOT NULL CHECK (upload_purpose IN ('name_change_document', 'feedback_attachment', 'profile_document', 'other')),
    related_request_id VARCHAR(50), -- Links to name_change_requests.request_id or feedback.id
    description TEXT,
    created_at TIMESTAMP DEFAULT now(),
    updated_at TIMESTAMP DEFAULT now()
);

-- 2. Add file upload support to name_change_requests table
ALTER TABLE name_change_requests 
ADD COLUMN IF NOT EXISTS supporting_documents_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS has_supporting_documents BOOLEAN DEFAULT false;

-- 3. Create feedback_submissions table for improvement suggestions
CREATE TABLE IF NOT EXISTS feedback_submissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    feedback_id VARCHAR(50) UNIQUE NOT NULL, -- e.g., "FB-1721174400000"
    
    -- Feedback content
    category VARCHAR(50) NOT NULL CHECK (category IN ('ui_ux', 'features', 'performance', 'content', 'accessibility', 'security', 'other')),
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    implementation_suggestion TEXT,
    priority_level VARCHAR(20) DEFAULT 'medium' CHECK (priority_level IN ('low', 'medium', 'high', 'critical')),
    
    -- User consent and reward tracking
    consent_for_contact BOOLEAN DEFAULT false,
    consent_for_implementation BOOLEAN DEFAULT false,
    reward_eligible BOOLEAN DEFAULT true,
    reward_granted BOOLEAN DEFAULT false,
    reward_type VARCHAR(50), -- e.g., '2_months_free'
    reward_granted_at TIMESTAMP,
    
    -- Status tracking
    status VARCHAR(20) DEFAULT 'submitted' CHECK (status IN ('submitted', 'under_review', 'planned', 'in_development', 'implemented', 'rejected')),
    admin_notes TEXT,
    implementation_notes TEXT,
    reviewed_by UUID REFERENCES users(id), -- admin who reviewed
    reviewed_at TIMESTAMP,
    implemented_at TIMESTAMP,
    
    -- Contact info for reward
    contact_email VARCHAR(255),
    contact_name VARCHAR(100),
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT now(),
    updated_at TIMESTAMP DEFAULT now()
);

-- 4. Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_file_uploads_user_id ON file_uploads(user_id);
CREATE INDEX IF NOT EXISTS idx_file_uploads_purpose ON file_uploads(upload_purpose);
CREATE INDEX IF NOT EXISTS idx_file_uploads_related_request ON file_uploads(related_request_id);

CREATE INDEX IF NOT EXISTS idx_feedback_submissions_user_id ON feedback_submissions(user_id);
CREATE INDEX IF NOT EXISTS idx_feedback_submissions_status ON feedback_submissions(status);
CREATE INDEX IF NOT EXISTS idx_feedback_submissions_category ON feedback_submissions(category);
CREATE INDEX IF NOT EXISTS idx_feedback_submissions_reward_eligible ON feedback_submissions(reward_eligible);

-- 5. Enable RLS on new tables
ALTER TABLE file_uploads ENABLE ROW LEVEL SECURITY;
ALTER TABLE feedback_submissions ENABLE ROW LEVEL SECURITY;

-- 6. Create RLS policies for file_uploads
CREATE POLICY "Users can view their own file uploads" ON file_uploads
    FOR SELECT USING (auth.uid()::text = user_id::text);

CREATE POLICY "Users can upload their own files" ON file_uploads
    FOR INSERT WITH CHECK (auth.uid()::text = user_id::text);

CREATE POLICY "Users can update their own file uploads" ON file_uploads
    FOR UPDATE USING (auth.uid()::text = user_id::text);

CREATE POLICY "Users can delete their own file uploads" ON file_uploads
    FOR DELETE USING (auth.uid()::text = user_id::text);

-- 7. Create RLS policies for feedback_submissions
CREATE POLICY "Users can view their own feedback submissions" ON feedback_submissions
    FOR SELECT USING (auth.uid()::text = user_id::text);

CREATE POLICY "Users can create feedback submissions" ON feedback_submissions
    FOR INSERT WITH CHECK (auth.uid()::text = user_id::text);

CREATE POLICY "Users can update their own feedback submissions" ON feedback_submissions
    FOR UPDATE USING (auth.uid()::text = user_id::text);

-- 8. Create storage bucket policies for file uploads (run in Supabase Storage section)
/*
-- In Supabase Dashboard > Storage > Policies, create these policies:

-- Bucket: name-change-documents
INSERT POLICY "Users can upload name change documents" ON storage.objects 
FOR INSERT WITH CHECK (bucket_id = 'name-change-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

SELECT POLICY "Users can view their own name change documents" ON storage.objects 
FOR SELECT USING (bucket_id = 'name-change-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

DELETE POLICY "Users can delete their own name change documents" ON storage.objects 
FOR DELETE USING (bucket_id = 'name-change-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Bucket: feedback-attachments
INSERT POLICY "Users can upload feedback attachments" ON storage.objects 
FOR INSERT WITH CHECK (bucket_id = 'feedback-attachments' AND auth.uid()::text = (storage.foldername(name))[1]);

SELECT POLICY "Users can view their own feedback attachments" ON storage.objects 
FOR SELECT USING (bucket_id = 'feedback-attachments' AND auth.uid()::text = (storage.foldername(name))[1]);

DELETE POLICY "Users can delete their own feedback attachments" ON storage.objects 
FOR DELETE USING (bucket_id = 'feedback-attachments' AND auth.uid()::text = (storage.foldername(name))[1]);
*/

-- 9. Create functions for business logic
CREATE OR REPLACE FUNCTION update_name_change_documents_count()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' AND NEW.upload_purpose = 'name_change_document' THEN
        UPDATE name_change_requests 
        SET supporting_documents_count = supporting_documents_count + 1,
            has_supporting_documents = true
        WHERE request_id = NEW.related_request_id;
    ELSIF TG_OP = 'DELETE' AND OLD.upload_purpose = 'name_change_document' THEN
        UPDATE name_change_requests 
        SET supporting_documents_count = GREATEST(supporting_documents_count - 1, 0)
        WHERE request_id = OLD.related_request_id;
        
        -- Update has_supporting_documents flag
        UPDATE name_change_requests 
        SET has_supporting_documents = (supporting_documents_count > 0)
        WHERE request_id = OLD.related_request_id;
    END IF;
    
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

-- 10. Create triggers
CREATE TRIGGER trigger_update_name_change_documents_count
    AFTER INSERT OR DELETE ON file_uploads
    FOR EACH ROW
    EXECUTE FUNCTION update_name_change_documents_count();

-- 11. Update timestamp triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_file_uploads_updated_at BEFORE UPDATE ON file_uploads
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_feedback_submissions_updated_at BEFORE UPDATE ON feedback_submissions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
