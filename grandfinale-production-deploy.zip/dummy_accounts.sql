-- Dummy Accounts for All Pricing Tiers
-- This SQL file creates dummy accounts for testing all pricing tiers
-- All accounts use info@epoxydogs.com as the email

-- Insert dummy users for all pricing tiers
INSERT INTO users (email, created_at, updated_at) VALUES
-- Monthly Plans
('info@epoxydogs.com', now(), now()),
('info@epoxydogs.com', now(), now()),
('info@epoxydogs.com', now(), now()),
('info@epoxydogs.com', now(), now()),

-- Yearly Plans  
('info@epoxydogs.com', now(), now()),
('info@epoxydogs.com', now(), now()),
('info@epoxydogs.com', now(), now()),
('info@epoxydogs.com', now(), now());

-- Insert personal information for each dummy account
INSERT INTO personal_info (user_id, legal_first_name, legal_last_name, preferred_name, date_of_birth, place_of_birth, country_of_citizenship, language_spoken, created_at, updated_at) VALUES
-- Monthly Plans
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 0), 'Dummy', 'Lite-Monthly', 'Dummy Lite', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 1), 'Dummy', 'Standard-Monthly', 'Dummy Standard', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 2), 'Dummy', 'Premium-Monthly', 'Dummy Premium', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 3), 'Dummy', 'Lifetime', 'Dummy Lifetime', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),

-- Yearly Plans
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 4), 'Dummy', 'Lite-Yearly', 'Dummy Lite Yearly', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 5), 'Dummy', 'Standard-Yearly', 'Dummy Standard Yearly', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 6), 'Dummy', 'Premium-Yearly', 'Dummy Premium Yearly', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 7), 'Dummy', 'Lifetime-Yearly', 'Dummy Lifetime Yearly', '1990-01-01', 'Test City', 'United States', 'English', now(), now());

-- Insert sample addresses for each dummy account
INSERT INTO addresses (user_id, address_type, street, city, state, zip, country, is_primary, created_at, updated_at) VALUES
-- Monthly Plans
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 0), 'Current', '123 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 1), 'Current', '456 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 2), 'Current', '789 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 3), 'Current', '101 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),

-- Yearly Plans
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 4), 'Current', '202 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 5), 'Current', '303 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 6), 'Current', '404 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 7), 'Current', '505 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now());

-- Insert sample phone numbers for each dummy account
INSERT INTO phones (user_id, phone_type, phone_number, is_primary, created_at, updated_at) VALUES
-- Monthly Plans
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 0), 'Mobile', '555-0101', true, now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 1), 'Mobile', '555-0102', true, now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 2), 'Mobile', '555-0103', true, now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 3), 'Mobile', '555-0104', true, now(), now()),

-- Yearly Plans
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 4), 'Mobile', '555-0105', true, now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 5), 'Mobile', '555-0106', true, now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 6), 'Mobile', '555-0107', true, now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 7), 'Mobile', '555-0108', true, now(), now());

-- Insert sample emergency contacts for each dummy account
INSERT INTO emergency_contacts (user_id, full_name, relationship, phone, email, address, city, state, zip, country, is_primary, notes, created_at, updated_at) VALUES
-- Monthly Plans
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 0), 'Test Contact Lite', 'Friend', '555-0201', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Lite Monthly plan', now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 1), 'Test Contact Standard', 'Friend', '555-0202', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Standard Monthly plan', now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 2), 'Test Contact Premium', 'Friend', '555-0203', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Premium Monthly plan', now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 3), 'Test Contact Lifetime', 'Friend', '555-0204', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Lifetime plan', now(), now()),

-- Yearly Plans
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 4), 'Test Contact Lite Yearly', 'Friend', '555-0205', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Lite Yearly plan', now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 5), 'Test Contact Standard Yearly', 'Friend', '555-0206', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Standard Yearly plan', now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 6), 'Test Contact Premium Yearly', 'Friend', '555-0207', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Premium Yearly plan', now(), now()),
((SELECT id FROM users WHERE email = 'info@epoxydogs.com' LIMIT 1 OFFSET 7), 'Test Contact Lifetime Yearly', 'Friend', '555-0208', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Lifetime Yearly plan', now(), now());

-- Display the created dummy accounts
SELECT 
    u.id as user_id,
    u.email,
    pi.legal_first_name,
    pi.legal_last_name,
    pi.preferred_name,
    a.street,
    a.city,
    a.state,
    p.phone_number,
    ec.full_name as emergency_contact
FROM users u
LEFT JOIN personal_info pi ON u.id = pi.user_id
LEFT JOIN addresses a ON u.id = a.user_id AND a.is_primary = true
LEFT JOIN phones p ON u.id = p.user_id AND p.is_primary = true
LEFT JOIN emergency_contacts ec ON u.id = ec.user_id AND ec.is_primary = true
WHERE u.email = 'info@epoxydogs.com'
ORDER BY pi.legal_last_name; 