-- Create the phones table for phone number to email mapping
-- This table stores user phone numbers for account recovery purposes

DROP TABLE IF EXISTS phones;

CREATE TABLE phones (
    id BIGSERIAL PRIMARY KEY,
    email TEXT NOT NULL,
    phone TEXT NOT NULL UNIQUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for faster lookups
CREATE INDEX idx_phones_email ON phones(email);
CREATE INDEX idx_phones_phone ON phones(phone);

-- Insert dummy data for testing (matching the existing dummy accounts)
INSERT INTO phones (email, phone) VALUES
    ('dummy.lite.monthly@epoxydogs.com', '234-567-890'),
    ('dummy.standard.monthly@epoxydogs.com', '234-567-891'),
    ('dummy.premium.monthly@epoxydogs.com', '234-567-892'),
    ('dummy.lifetime.onetime@epoxydogs.com', '234-567-893');
