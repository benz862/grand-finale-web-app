-- Create Database Records for Remaining Dummy Accounts
-- Run this AFTER creating the remaining 6 auth users via Supabase Dashboard
-- (We only need 7 total accounts, not 8, since Lifetime is the same for monthly/yearly)

-- First, let's get the UUIDs of the remaining auth users
SELECT id, email FROM auth.users WHERE email LIKE 'dummy.%@epoxydogs.com' ORDER BY email;

-- Then use those UUIDs to create the database records
-- (Replace the UUIDs below with the actual UUIDs from the query above)

-- Insert users table records for remaining accounts
INSERT INTO users (id, email, created_at, updated_at) 
SELECT 
    id, 
    email, 
    created_at, 
    updated_at
FROM auth.users 
WHERE email LIKE 'dummy.%@epoxydogs.com' 
AND email != 'dummy.lite.monthly@epoxydogs.com'
ON CONFLICT (id) DO NOTHING;

-- Insert personal information for remaining dummy accounts
-- (This will be done after we get the actual UUIDs)

-- For now, here's the template for each user (6 remaining accounts):
/*
INSERT INTO personal_info (user_id, legal_first_name, legal_last_name, preferred_name, date_of_birth, place_of_birth, country_of_citizenship, language_spoken, created_at, updated_at) 
VALUES 
('UUID-FROM-AUTH-USERS', 'Dummy', 'Standard-Monthly', 'Dummy Standard', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
('UUID-FROM-AUTH-USERS', 'Dummy', 'Premium-Monthly', 'Dummy Premium', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
('UUID-FROM-AUTH-USERS', 'Dummy', 'Lifetime', 'Dummy Lifetime', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
('UUID-FROM-AUTH-USERS', 'Dummy', 'Lite-Yearly', 'Dummy Lite Yearly', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
('UUID-FROM-AUTH-USERS', 'Dummy', 'Standard-Yearly', 'Dummy Standard Yearly', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
('UUID-FROM-AUTH-USERS', 'Dummy', 'Premium-Yearly', 'Dummy Premium Yearly', '1990-01-01', 'Test City', 'United States', 'English', now(), now());
*/

-- Check current status
SELECT 
    u.id as user_id,
    u.email,
    CASE 
        WHEN pi.legal_first_name IS NOT NULL THEN 'Complete'
        ELSE 'Auth Only'
    END as status
FROM users u
LEFT JOIN personal_info pi ON u.id = pi.user_id
WHERE u.email LIKE 'dummy.%@epoxydogs.com'
ORDER BY u.email; 