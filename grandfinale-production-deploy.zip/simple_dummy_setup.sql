-- SIMPLE DUMMY ACCOUNTS SETUP
-- This is the correct order to avoid conflicts

-- STEP 1: Create Auth Users First
-- Go to Supabase Dashboard → Authentication → Users → Add User
-- Create these 8 users manually:

/*
1. Email: dummy.lite.monthly@epoxydogs.com, Password: DummyLite2024!
2. Email: dummy.standard.monthly@epoxydogs.com, Password: DummyStandard2024!
3. Email: dummy.premium.monthly@epoxydogs.com, Password: DummyPremium2024!
4. Email: dummy.lifetime@epoxydogs.com, Password: DummyLifetime2024!
5. Email: dummy.lite.yearly@epoxydogs.com, Password: DummyLiteYearly2024!
6. Email: dummy.standard.yearly@epoxydogs.com, Password: DummyStandardYearly2024!
7. Email: dummy.premium.yearly@epoxydogs.com, Password: DummyPremiumYearly2024!
8. Email: dummy.lifetime.yearly@epoxydogs.com, Password: DummyLifetimeYearly2024!
*/

-- STEP 2: After creating auth users, run this to get their UUIDs
SELECT id, email FROM auth.users WHERE email LIKE 'dummy.%@epoxydogs.com';

-- STEP 3: Copy the UUIDs from the query above and use them in the INSERT statements below
-- Replace the UUIDs in the INSERT statements with the actual UUIDs from step 2

-- Example (replace with actual UUIDs from step 2):
/*
INSERT INTO users (id, email, created_at, updated_at) VALUES
('ACTUAL-UUID-FROM-STEP-2', 'dummy.lite.monthly@epoxydogs.com', now(), now()),
('ACTUAL-UUID-FROM-STEP-2', 'dummy.standard.monthly@epoxydogs.com', now(), now()),
-- ... continue for all 8 users
*/ 