-- Test Access Restrictions for Dummy Accounts
-- This script shows what sections each dummy account should have access to

SELECT 
    'Access Restrictions Test' as test_type,
    u.email,
    pi.legal_first_name,
    pi.legal_last_name,
    CASE 
        WHEN u.email LIKE '%.lite.%' THEN 'Lite'
        WHEN u.email LIKE '%.standard.%' THEN 'Standard'
        WHEN u.email LIKE '%.premium.%' THEN 'Premium'
        WHEN u.email LIKE '%.lifetime@%' THEN 'Lifetime'
        ELSE 'Unknown'
    END as tier,
    CASE 
        WHEN u.email LIKE '%.monthly@%' THEN 'Monthly'
        WHEN u.email LIKE '%.yearly@%' THEN 'Yearly'
        WHEN u.email LIKE '%.lifetime@%' THEN 'Lifetime'
        ELSE 'Unknown'
    END as billing,
    CASE 
        WHEN u.email LIKE '%.lite.%' THEN 'Sections 1-5 (Intro, Personal Info, Medical, Legal, Finance)'
        WHEN u.email LIKE '%.standard.%' THEN 'Sections 1-10 (All Lite + Beneficiaries, Property, Digital, Contacts, Funeral)'
        WHEN u.email LIKE '%.premium.%' THEN 'Sections 1-15 (All Standard + Pets, Letters, Legacy, Bucket List, Formal Letters)'
        WHEN u.email LIKE '%.lifetime@%' THEN 'All Sections (1-16 + File Uploads)'
        ELSE 'Unknown'
    END as access_level
FROM users u
LEFT JOIN personal_info pi ON u.id = pi.user_id
WHERE u.email LIKE '%@epoxydogs.com'
ORDER BY 
    CASE 
        WHEN u.email LIKE '%.lite.%' THEN 1
        WHEN u.email LIKE '%.standard.%' THEN 2
        WHEN u.email LIKE '%.premium.%' THEN 3
        WHEN u.email LIKE '%.lifetime@%' THEN 4
        ELSE 5
    END,
    u.email; 