-- Complete Setup for All 7 Dummy Accounts (FIXED)
-- This script will create all database records for the 7 dummy accounts

-- Step 1: Get all the UUIDs from auth.users
SELECT id, email FROM auth.users WHERE email LIKE 'dummy.%@epoxydogs.com' ORDER BY email;

-- Step 2: Insert user records for all accounts (if not already done by trigger)
INSERT INTO users (id, email, created_at, updated_at) 
SELECT 
    id, 
    email, 
    created_at, 
    updated_at
FROM auth.users 
WHERE email LIKE 'dummy.%@epoxydogs.com'
ON CONFLICT (id) DO NOTHING;

-- Step 3: Insert personal information for all accounts
-- First, let's create a temporary table with the mappings
CREATE TEMP TABLE user_mappings AS
SELECT 
    id,
    email,
    CASE 
        WHEN email = 'dummy.lite.monthly@epoxydogs.com' THEN 'Dummy Lite-Monthly'
        WHEN email = 'dummy.standard.monthly@epoxydogs.com' THEN 'Dummy Standard-Monthly'
        WHEN email = 'dummy.premium.monthly@epoxydogs.com' THEN 'Dummy Premium-Monthly'
        WHEN email = 'dummy.lifetime@epoxydogs.com' THEN 'Dummy Lifetime'
        WHEN email = 'dummy.lite.yearly@epoxydogs.com' THEN 'Dummy Lite-Yearly'
        WHEN email = 'dummy.standard.yearly@epoxydogs.com' THEN 'Dummy Standard-Yearly'
        WHEN email = 'dummy.premium.yearly@epoxydogs.com' THEN 'Dummy Premium-Yearly'
    END as last_name,
    CASE 
        WHEN email = 'dummy.lite.monthly@epoxydogs.com' THEN 'Dummy Lite'
        WHEN email = 'dummy.standard.monthly@epoxydogs.com' THEN 'Dummy Standard'
        WHEN email = 'dummy.premium.monthly@epoxydogs.com' THEN 'Dummy Premium'
        WHEN email = 'dummy.lifetime@epoxydogs.com' THEN 'Dummy Lifetime'
        WHEN email = 'dummy.lite.yearly@epoxydogs.com' THEN 'Dummy Lite Yearly'
        WHEN email = 'dummy.standard.yearly@epoxydogs.com' THEN 'Dummy Standard Yearly'
        WHEN email = 'dummy.premium.yearly@epoxydogs.com' THEN 'Dummy Premium Yearly'
    END as preferred_name
FROM auth.users 
WHERE email LIKE 'dummy.%@epoxydogs.com';

-- Insert personal information (removed ON CONFLICT)
INSERT INTO personal_info (user_id, legal_first_name, legal_last_name, preferred_name, date_of_birth, place_of_birth, country_of_citizenship, language_spoken, created_at, updated_at)
SELECT 
    um.id,
    'Dummy',
    um.last_name,
    um.preferred_name,
    '1990-01-01',
    'Test City',
    'United States',
    'English',
    now(),
    now()
FROM user_mappings um;

-- Step 4: Insert addresses for all accounts (removed ON CONFLICT)
INSERT INTO addresses (user_id, address_type, street, city, state, zip, country, is_primary, created_at, updated_at)
SELECT 
    um.id,
    'Current',
    CASE 
        WHEN um.email = 'dummy.lite.monthly@epoxydogs.com' THEN '123 Test Street'
        WHEN um.email = 'dummy.standard.monthly@epoxydogs.com' THEN '456 Test Street'
        WHEN um.email = 'dummy.premium.monthly@epoxydogs.com' THEN '789 Test Street'
        WHEN um.email = 'dummy.lifetime@epoxydogs.com' THEN '101 Test Street'
        WHEN um.email = 'dummy.lite.yearly@epoxydogs.com' THEN '202 Test Street'
        WHEN um.email = 'dummy.standard.yearly@epoxydogs.com' THEN '303 Test Street'
        WHEN um.email = 'dummy.premium.yearly@epoxydogs.com' THEN '404 Test Street'
    END as street,
    'Test City',
    'Test State',
    '12345',
    'United States',
    true,
    now(),
    now()
FROM user_mappings um;

-- Step 5: Insert phone numbers for all accounts (removed ON CONFLICT)
INSERT INTO phones (user_id, phone_type, phone_number, is_primary, created_at, updated_at)
SELECT 
    um.id,
    'Mobile',
    CASE 
        WHEN um.email = 'dummy.lite.monthly@epoxydogs.com' THEN '555-0101'
        WHEN um.email = 'dummy.standard.monthly@epoxydogs.com' THEN '555-0102'
        WHEN um.email = 'dummy.premium.monthly@epoxydogs.com' THEN '555-0103'
        WHEN um.email = 'dummy.lifetime@epoxydogs.com' THEN '555-0104'
        WHEN um.email = 'dummy.lite.yearly@epoxydogs.com' THEN '555-0105'
        WHEN um.email = 'dummy.standard.yearly@epoxydogs.com' THEN '555-0106'
        WHEN um.email = 'dummy.premium.yearly@epoxydogs.com' THEN '555-0107'
    END as phone_number,
    true,
    now(),
    now()
FROM user_mappings um;

-- Step 6: Insert emergency contacts for all accounts (removed ON CONFLICT)
INSERT INTO emergency_contacts (user_id, full_name, relationship, phone, email, address, city, state, zip, country, is_primary, notes, created_at, updated_at)
SELECT 
    um.id,
    CASE 
        WHEN um.email = 'dummy.lite.monthly@epoxydogs.com' THEN 'Test Contact Lite'
        WHEN um.email = 'dummy.standard.monthly@epoxydogs.com' THEN 'Test Contact Standard'
        WHEN um.email = 'dummy.premium.monthly@epoxydogs.com' THEN 'Test Contact Premium'
        WHEN um.email = 'dummy.lifetime@epoxydogs.com' THEN 'Test Contact Lifetime'
        WHEN um.email = 'dummy.lite.yearly@epoxydogs.com' THEN 'Test Contact Lite Yearly'
        WHEN um.email = 'dummy.standard.yearly@epoxydogs.com' THEN 'Test Contact Standard Yearly'
        WHEN um.email = 'dummy.premium.yearly@epoxydogs.com' THEN 'Test Contact Premium Yearly'
    END as full_name,
    'Friend',
    CASE 
        WHEN um.email = 'dummy.lite.monthly@epoxydogs.com' THEN '555-0201'
        WHEN um.email = 'dummy.standard.monthly@epoxydogs.com' THEN '555-0202'
        WHEN um.email = 'dummy.premium.monthly@epoxydogs.com' THEN '555-0203'
        WHEN um.email = 'dummy.lifetime@epoxydogs.com' THEN '555-0204'
        WHEN um.email = 'dummy.lite.yearly@epoxydogs.com' THEN '555-0205'
        WHEN um.email = 'dummy.standard.yearly@epoxydogs.com' THEN '555-0206'
        WHEN um.email = 'dummy.premium.yearly@epoxydogs.com' THEN '555-0207'
    END as phone,
    'contact@test.com',
    '123 Contact St',
    'Test City',
    'Test State',
    '12345',
    'United States',
    true,
    CASE 
        WHEN um.email = 'dummy.lite.monthly@epoxydogs.com' THEN 'Emergency contact for Lite Monthly plan'
        WHEN um.email = 'dummy.standard.monthly@epoxydogs.com' THEN 'Emergency contact for Standard Monthly plan'
        WHEN um.email = 'dummy.premium.monthly@epoxydogs.com' THEN 'Emergency contact for Premium Monthly plan'
        WHEN um.email = 'dummy.lifetime@epoxydogs.com' THEN 'Emergency contact for Lifetime plan'
        WHEN um.email = 'dummy.lite.yearly@epoxydogs.com' THEN 'Emergency contact for Lite Yearly plan'
        WHEN um.email = 'dummy.standard.yearly@epoxydogs.com' THEN 'Emergency contact for Standard Yearly plan'
        WHEN um.email = 'dummy.premium.yearly@epoxydogs.com' THEN 'Emergency contact for Premium Yearly plan'
    END as notes,
    now(),
    now()
FROM user_mappings um;

-- Step 7: Verify all accounts are complete
SELECT 
    u.id as user_id,
    u.email,
    pi.legal_first_name,
    pi.legal_last_name,
    pi.preferred_name,
    a.street,
    a.city,
    a.state,
    p.phone_number,
    ec.full_name as emergency_contact,
    CASE 
        WHEN pi.legal_first_name IS NOT NULL AND a.street IS NOT NULL AND p.phone_number IS NOT NULL AND ec.full_name IS NOT NULL 
        THEN 'Complete'
        ELSE 'Incomplete'
    END as status
FROM users u
LEFT JOIN personal_info pi ON u.id = pi.user_id
LEFT JOIN addresses a ON u.id = a.user_id AND a.is_primary = true
LEFT JOIN phones p ON u.id = p.user_id AND p.is_primary = true
LEFT JOIN emergency_contacts ec ON u.id = ec.user_id AND ec.is_primary = true
WHERE u.email LIKE 'dummy.%@epoxydogs.com'
ORDER BY u.email;

-- Clean up
DROP TABLE user_mappings; 