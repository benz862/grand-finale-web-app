-- Test Authentication Status for Dummy Accounts
-- This script checks if dummy users exist in both auth.users and public.users tables

-- Check auth.users table (Supabase Auth)
SELECT 
    'Auth Users' as table_name,
    id,
    email,
    created_at,
    CASE 
        WHEN email LIKE '%.lite.%' THEN 'Lite'
        WHEN email LIKE '%.standard.%' THEN 'Standard'
        WHEN email LIKE '%.premium.%' THEN 'Premium'
        WHEN email LIKE '%.lifetime@%' THEN 'Lifetime'
        ELSE 'Unknown'
    END as tier
FROM auth.users 
WHERE email LIKE '%@epoxydogs.com'
ORDER BY email;

-- Check public.users table (our app's user table)
SELECT 
    'Public Users' as table_name,
    id,
    email,
    created_at
FROM users 
WHERE email LIKE '%@epoxydogs.com'
ORDER BY email;

-- Check if there's a mismatch between auth and public users
SELECT 
    'Auth Only' as status,
    au.email
FROM auth.users au
LEFT JOIN users u ON au.id = u.id
WHERE au.email LIKE '%@epoxydogs.com' AND u.id IS NULL

UNION ALL

SELECT 
    'Public Only' as status,
    u.email
FROM users u
LEFT JOIN auth.users au ON u.id = au.id
WHERE u.email LIKE '%@epoxydogs.com' AND au.id IS NULL

UNION ALL

SELECT 
    'Both Tables' as status,
    u.email
FROM users u
INNER JOIN auth.users au ON u.id = au.id
WHERE u.email LIKE '%@epoxydogs.com';