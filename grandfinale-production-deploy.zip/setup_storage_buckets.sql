-- Setup Storage Buckets and Policies for File Uploads
-- Run this in your Supabase SQL Editor

-- 1. Create storage buckets
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES 
    (
        'name-change-documents',
        'name-change-documents',
        false, -- private bucket
        10485760, -- 10MB limit
        ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf', 'text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'video/mp4', 'video/webm', 'video/quicktime']
    ),
    (
        'feedback-attachments',
        'feedback-attachments', 
        false, -- private bucket
        10485760, -- 10MB limit
        ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf', 'text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'video/mp4', 'video/webm', 'video/quicktime']
    )
ON CONFLICT (id) DO NOTHING;

-- 2. Create storage policies for name-change-documents bucket
-- Allow users to upload their own documents
CREATE POLICY "Users can upload name change documents" ON storage.objects
FOR INSERT WITH CHECK (
    bucket_id = 'name-change-documents' 
    AND auth.uid()::text = (storage.foldername(name))[1]
    AND auth.role() = 'authenticated'
);

-- Allow users to view their own documents
CREATE POLICY "Users can view their own name change documents" ON storage.objects
FOR SELECT USING (
    bucket_id = 'name-change-documents' 
    AND auth.uid()::text = (storage.foldername(name))[1]
    AND auth.role() = 'authenticated'
);

-- Allow users to delete their own documents
CREATE POLICY "Users can delete their own name change documents" ON storage.objects
FOR DELETE USING (
    bucket_id = 'name-change-documents' 
    AND auth.uid()::text = (storage.foldername(name))[1]
    AND auth.role() = 'authenticated'
);

-- 3. Create storage policies for feedback-attachments bucket
-- Allow users to upload feedback attachments
CREATE POLICY "Users can upload feedback attachments" ON storage.objects
FOR INSERT WITH CHECK (
    bucket_id = 'feedback-attachments' 
    AND auth.uid()::text = (storage.foldername(name))[1]
    AND auth.role() = 'authenticated'
);

-- Allow users to view their own feedback attachments
CREATE POLICY "Users can view their own feedback attachments" ON storage.objects
FOR SELECT USING (
    bucket_id = 'feedback-attachments' 
    AND auth.uid()::text = (storage.foldername(name))[1]
    AND auth.role() = 'authenticated'
);

-- Allow users to delete their own feedback attachments
CREATE POLICY "Users can delete their own feedback attachments" ON storage.objects
FOR DELETE USING (
    bucket_id = 'feedback-attachments' 
    AND auth.uid()::text = (storage.foldername(name))[1]
    AND auth.role() = 'authenticated'
);

-- 4. Verify the setup
SELECT 
    b.id as bucket_id,
    b.name as bucket_name,
    b.public,
    b.file_size_limit / 1024 / 1024 as max_size_mb,
    b.allowed_mime_types
FROM storage.buckets b
WHERE b.id IN ('name-change-documents', 'feedback-attachments');
