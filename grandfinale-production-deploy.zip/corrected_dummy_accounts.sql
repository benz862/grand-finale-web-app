-- CORRECTED: Dummy Accounts Setup
-- This script creates auth users first, then database records
-- Run this in your Supabase SQL editor

-- Step 1: First, create the auth users via Supabase Dashboard or CLI
-- Go to Supabase Dashboard → Authentication → Users → Add User
-- Create these 8 users:

/*
1. Email: dummy.lite.monthly@epoxydogs.com, Password: DummyLite2024!
2. Email: dummy.standard.monthly@epoxydogs.com, Password: DummyStandard2024!
3. Email: dummy.premium.monthly@epoxydogs.com, Password: DummyPremium2024!
4. Email: dummy.lifetime@epoxydogs.com, Password: DummyLifetime2024!
5. Email: dummy.lite.yearly@epoxydogs.com, Password: DummyLiteYearly2024!
6. Email: dummy.standard.yearly@epoxydogs.com, Password: DummyStandardYearly2024!
7. Email: dummy.premium.yearly@epoxydogs.com, Password: DummyPremiumYearly2024!
8. Email: dummy.lifetime.yearly@epoxydogs.com, Password: DummyLifetimeYearly2024!
*/

-- Step 2: After creating auth users, run this SQL to create database records
-- This assumes the auth users already exist and will link to them

-- Insert users table records (these should match the auth.users table)
INSERT INTO users (id, email, created_at, updated_at) VALUES
-- Monthly Plans
('00000000-0000-0000-0000-000000000001', 'dummy.lite.monthly@epoxydogs.com', now(), now()),
('00000000-0000-0000-0000-000000000002', 'dummy.standard.monthly@epoxydogs.com', now(), now()),
('00000000-0000-0000-0000-000000000003', 'dummy.premium.monthly@epoxydogs.com', now(), now()),
('00000000-0000-0000-0000-000000000004', 'dummy.lifetime@epoxydogs.com', now(), now()),

-- Yearly Plans  
('00000000-0000-0000-0000-000000000005', 'dummy.lite.yearly@epoxydogs.com', now(), now()),
('00000000-0000-0000-0000-000000000006', 'dummy.standard.yearly@epoxydogs.com', now(), now()),
('00000000-0000-0000-0000-000000000007', 'dummy.premium.yearly@epoxydogs.com', now(), now()),
('00000000-0000-0000-0000-000000000008', 'dummy.lifetime.yearly@epoxydogs.com', now(), now());

-- Insert personal information for each dummy account
INSERT INTO personal_info (user_id, legal_first_name, legal_last_name, preferred_name, date_of_birth, place_of_birth, country_of_citizenship, language_spoken, created_at, updated_at) VALUES
-- Monthly Plans
('00000000-0000-0000-0000-000000000001', 'Dummy', 'Lite-Monthly', 'Dummy Lite', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
('00000000-0000-0000-0000-000000000002', 'Dummy', 'Standard-Monthly', 'Dummy Standard', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
('00000000-0000-0000-0000-000000000003', 'Dummy', 'Premium-Monthly', 'Dummy Premium', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
('00000000-0000-0000-0000-000000000004', 'Dummy', 'Lifetime', 'Dummy Lifetime', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),

-- Yearly Plans
('00000000-0000-0000-0000-000000000005', 'Dummy', 'Lite-Yearly', 'Dummy Lite Yearly', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
('00000000-0000-0000-0000-000000000006', 'Dummy', 'Standard-Yearly', 'Dummy Standard Yearly', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
('00000000-0000-0000-0000-000000000007', 'Dummy', 'Premium-Yearly', 'Dummy Premium Yearly', '1990-01-01', 'Test City', 'United States', 'English', now(), now()),
('00000000-0000-0000-0000-000000000008', 'Dummy', 'Lifetime-Yearly', 'Dummy Lifetime Yearly', '1990-01-01', 'Test City', 'United States', 'English', now(), now());

-- Insert sample addresses for each dummy account
INSERT INTO addresses (user_id, address_type, street, city, state, zip, country, is_primary, created_at, updated_at) VALUES
-- Monthly Plans
('00000000-0000-0000-0000-000000000001', 'Current', '123 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
('00000000-0000-0000-0000-000000000002', 'Current', '456 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
('00000000-0000-0000-0000-000000000003', 'Current', '789 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
('00000000-0000-0000-0000-000000000004', 'Current', '101 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),

-- Yearly Plans
('00000000-0000-0000-0000-000000000005', 'Current', '202 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
('00000000-0000-0000-0000-000000000006', 'Current', '303 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
('00000000-0000-0000-0000-000000000007', 'Current', '404 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now()),
('00000000-0000-0000-0000-000000000008', 'Current', '505 Test Street', 'Test City', 'Test State', '12345', 'United States', true, now(), now());

-- Insert sample phone numbers for each dummy account
INSERT INTO phones (user_id, phone_type, phone_number, is_primary, created_at, updated_at) VALUES
-- Monthly Plans
('00000000-0000-0000-0000-000000000001', 'Mobile', '555-0101', true, now(), now()),
('00000000-0000-0000-0000-000000000002', 'Mobile', '555-0102', true, now(), now()),
('00000000-0000-0000-0000-000000000003', 'Mobile', '555-0103', true, now(), now()),
('00000000-0000-0000-0000-000000000004', 'Mobile', '555-0104', true, now(), now()),

-- Yearly Plans
('00000000-0000-0000-0000-000000000005', 'Mobile', '555-0105', true, now(), now()),
('00000000-0000-0000-0000-000000000006', 'Mobile', '555-0106', true, now(), now()),
('00000000-0000-0000-0000-000000000007', 'Mobile', '555-0107', true, now(), now()),
('00000000-0000-0000-0000-000000000008', 'Mobile', '555-0108', true, now(), now());

-- Insert sample emergency contacts for each dummy account
INSERT INTO emergency_contacts (user_id, full_name, relationship, phone, email, address, city, state, zip, country, is_primary, notes, created_at, updated_at) VALUES
-- Monthly Plans
('00000000-0000-0000-0000-000000000001', 'Test Contact Lite', 'Friend', '555-0201', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Lite Monthly plan', now(), now()),
('00000000-0000-0000-0000-000000000002', 'Test Contact Standard', 'Friend', '555-0202', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Standard Monthly plan', now(), now()),
('00000000-0000-0000-0000-000000000003', 'Test Contact Premium', 'Friend', '555-0203', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Premium Monthly plan', now(), now()),
('00000000-0000-0000-0000-000000000004', 'Test Contact Lifetime', 'Friend', '555-0204', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Lifetime plan', now(), now()),

-- Yearly Plans
('00000000-0000-0000-0000-000000000005', 'Test Contact Lite Yearly', 'Friend', '555-0205', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Lite Yearly plan', now(), now()),
('00000000-0000-0000-0000-000000000006', 'Test Contact Standard Yearly', 'Friend', '555-0206', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Standard Yearly plan', now(), now()),
('00000000-0000-0000-0000-000000000007', 'Test Contact Premium Yearly', 'Friend', '555-0207', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Premium Yearly plan', now(), now()),
('00000000-0000-0000-0000-000000000008', 'Test Contact Lifetime Yearly', 'Friend', '555-0208', 'contact@test.com', '123 Contact St', 'Test City', 'Test State', '12345', 'United States', true, 'Emergency contact for Lifetime Yearly plan', now(), now());

-- Display the created dummy accounts
SELECT 
    u.id as user_id,
    u.email,
    pi.legal_first_name,
    pi.legal_last_name,
    pi.preferred_name,
    a.street,
    a.city,
    a.state,
    p.phone_number,
    ec.full_name as emergency_contact
FROM users u
LEFT JOIN personal_info pi ON u.id = pi.user_id
LEFT JOIN addresses a ON u.id = a.user_id AND a.is_primary = true
LEFT JOIN phones p ON u.id = p.user_id AND p.is_primary = true
LEFT JOIN emergency_contacts ec ON u.id = ec.user_id AND ec.is_primary = true
WHERE u.email LIKE 'dummy.%@epoxydogs.com'
ORDER BY pi.legal_last_name; 