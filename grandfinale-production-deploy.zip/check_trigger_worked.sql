-- Check if the trigger worked and created the user record
-- Run this to verify the auth user was synced to your users table

-- Check if the user exists in your users table
SELECT * FROM users WHERE email = 'dummy.lite.monthly@epoxydogs.com';

-- Check if the user exists in auth.users table
SELECT id, email, created_at FROM auth.users WHERE email = 'dummy.lite.monthly@epoxydogs.com';

-- If the trigger didn't work, manually insert the user record
-- (This should match the UUID from the auth.users table)
INSERT INTO users (id, email, created_at, updated_at) 
VALUES (
    '5e51b79d-a8ea-4022-bb41-9ccc519fc3f7', 
    'dummy.lite.monthly@epoxydogs.com', 
    '2025-07-16 17:48:59.885821+00', 
    '2025-07-16 17:48:59.902685+00'
) ON CONFLICT (id) DO NOTHING;

-- Now create the personal information for this user
INSERT INTO personal_info (user_id, legal_first_name, legal_last_name, preferred_name, date_of_birth, place_of_birth, country_of_citizenship, language_spoken, created_at, updated_at) 
VALUES (
    '5e51b79d-a8ea-4022-bb41-9ccc519fc3f7', 
    'Dummy', 
    'Lite-Monthly', 
    'Dummy Lite', 
    '1990-01-01', 
    'Test City', 
    'United States', 
    'English', 
    now(), 
    now()
);

-- Create sample address
INSERT INTO addresses (user_id, address_type, street, city, state, zip, country, is_primary, created_at, updated_at) 
VALUES (
    '5e51b79d-a8ea-4022-bb41-9ccc519fc3f7', 
    'Current', 
    '123 Test Street', 
    'Test City', 
    'Test State', 
    '12345', 
    'United States', 
    true, 
    now(), 
    now()
);

-- Create sample phone
INSERT INTO phones (user_id, phone_type, phone_number, is_primary, created_at, updated_at) 
VALUES (
    '5e51b79d-a8ea-4022-bb41-9ccc519fc3f7', 
    'Mobile', 
    '555-0101', 
    true, 
    now(), 
    now()
);

-- Create sample emergency contact
INSERT INTO emergency_contacts (user_id, full_name, relationship, phone, email, address, city, state, zip, country, is_primary, notes, created_at, updated_at) 
VALUES (
    '5e51b79d-a8ea-4022-bb41-9ccc519fc3f7', 
    'Test Contact Lite', 
    'Friend', 
    '555-0201', 
    'contact@test.com', 
    '123 Contact St', 
    'Test City', 
    'Test State', 
    '12345', 
    'United States', 
    true, 
    'Emergency contact for Lite Monthly plan', 
    now(), 
    now()
);

-- Verify everything was created
SELECT 
    u.id as user_id,
    u.email,
    pi.legal_first_name,
    pi.legal_last_name,
    pi.preferred_name,
    a.street,
    a.city,
    a.state,
    p.phone_number,
    ec.full_name as emergency_contact
FROM users u
LEFT JOIN personal_info pi ON u.id = pi.user_id
LEFT JOIN addresses a ON u.id = a.user_id AND a.is_primary = true
LEFT JOIN phones p ON u.id = p.user_id AND p.is_primary = true
LEFT JOIN emergency_contacts ec ON u.id = ec.user_id AND ec.is_primary = true
WHERE u.email = 'dummy.lite.monthly@epoxydogs.com'; 